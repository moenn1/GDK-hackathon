package com.example.publisher.model;

import io.micronaut.core.annotation.Introspected;
import io.micronaut.data.annotation.GeneratedValue;
import io.micronaut.data.annotation.Id;
import io.micronaut.data.annotation.MappedEntity;
import io.micronaut.data.annotation.Relation;
import io.micronaut.data.annotation.sql.JoinColumn;
import io.micronaut.serde.annotation.Serdeable;


import java.util.List;

@Serdeable
@Introspected
@MappedEntity
public class Participant {

    @Id
    @GeneratedValue
    private Long id;

    private String displayName;

    private String email;

    @Relation(Relation.Kind.MANY_TO_ONE)
    @JoinColumn(name = "team_id")
    private Team team;

    @Relation(value = Relation.Kind.ONE_TO_MANY, mappedBy = "participant", cascade = Relation.Cascade.ALL)
    private List<AggregatedIssue> issues;

    public Participant() {
    }

    public Participant(Long id, String displayName, String email, Team team, List<AggregatedIssue> issues) {
        this.id = id;
        this.displayName = displayName;
        this.email = email;
        this.team = team;
        this.issues = issues;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Team getTeam() {
        return team;
    }

    public void setTeam(Team team) {
        this.team = team;
    }

    public List<AggregatedIssue> getIssues() {
        return issues;
    }

    public void setIssues(List<AggregatedIssue> issues) {
        this.issues = issues;
    }
}

