package com.example.publisher.http;

import io.micronaut.scheduling.annotation.Scheduled;
import jakarta.inject.Singleton;

@Singleton
public class JiraScheduler {

    private final JiraService jiraService;

    public JiraScheduler(JiraService jiraService) {
        this.jiraService = jiraService;
    }

    @Scheduled(fixedDelay = "30s")
    public void checkForTickets(){
        jiraService.checkForTickets();
    }
}
