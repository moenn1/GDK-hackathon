package com.example.publisher.kafka;

import com.example.publisher.model.AggregatedIssue;
import io.micronaut.configuration.kafka.annotation.KafkaClient;
import io.micronaut.configuration.kafka.annotation.Topic;

@KafkaClient
public interface IssueClient {
    @Topic("issues")
    void sendIssue(AggregatedIssue issue);
}
