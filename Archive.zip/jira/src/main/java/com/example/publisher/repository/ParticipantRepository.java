package com.example.publisher.repository;

import com.example.publisher.model.Participant;
import io.micronaut.data.annotation.Query;
import io.micronaut.data.jdbc.annotation.JdbcRepository;
import io.micronaut.data.model.query.builder.sql.Dialect;
import io.micronaut.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

@JdbcRepository(dialect = Dialect.MYSQL)
public interface ParticipantRepository extends CrudRepository<Participant, Long> {
    Participant findByDisplayName(String displayName);
    Participant findByEmail(String email);
    @Query("SELECT * FROM participant WHERE team_id = :teamId")
    Optional<List<Participant>> findByTeamId(Long teamId);
}
