package com.example.publisher.mapper;

import com.example.publisher.model.AggregatedIssue;
import com.example.publisher.model.JiraIssuesResponse;
import com.example.publisher.model.Participant;
import com.example.publisher.repository.ParticipantRepository;
import com.example.publisher.util.IssueType;
import jakarta.inject.Singleton;

import java.util.ArrayList;
import java.util.List;

@Singleton
public class IssueMapper {

    private final ParticipantRepository participantRepository;

    public IssueMapper(ParticipantRepository participantRepository) {
        this.participantRepository = participantRepository;
    }

    public AggregatedIssue fromIssue(JiraIssuesResponse.Issue issue, IssueType type) {
        if (issue != null && issue.getFields() != null && issue.getFields().getReporter() != null) {
            Participant participant = participantRepository.findByEmail(issue.getFields().getReporter().getEmailAddress());
            return new AggregatedIssue(
                    issue.getKey(),
                    type,
                    participant
            );
        }
        return null;
    }

    public List<AggregatedIssue> fromIssues(JiraIssuesResponse jiraIssuesResponse, IssueType type) {
        List<AggregatedIssue> aggregatedIssues = new ArrayList<>();
        if (jiraIssuesResponse != null && jiraIssuesResponse.getIssues() != null) {
            for (JiraIssuesResponse.Issue issue : jiraIssuesResponse.getIssues()) {
                AggregatedIssue aggregatedIssue = fromIssue(issue, type);
                if (aggregatedIssue != null) {
                    aggregatedIssues.add(aggregatedIssue);
                }
            }
        }
        return aggregatedIssues;
    }

}
