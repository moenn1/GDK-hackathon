package com.example.publisher.repository;

import com.example.publisher.model.AggregatedIssue;
import com.example.publisher.util.IssueType;
import io.micronaut.core.annotation.Introspected;
import io.micronaut.data.annotation.Query;
import io.micronaut.data.jdbc.annotation.JdbcRepository;
import io.micronaut.data.model.query.builder.sql.Dialect;
import io.micronaut.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

@JdbcRepository(dialect = Dialect.MYSQL)
public interface AggregatedIssueRepository extends CrudRepository<AggregatedIssue, Long>{
    AggregatedIssue findByKey(String key);
    @Query("SELECT * FROM aggregated_issue WHERE type = :type")
    Optional<List<AggregatedIssue>> findByIssueType(IssueType type);
    @Query("SELECT * FROM aggregated_issue WHERE participant_id = :participantId")
    Optional<List<AggregatedIssue>> findByParticipantId(Long participantId);
    //query needs to fetch the participant's team id from the participant table
    @Query("SELECT * FROM aggregated_issue WHERE participant_id IN (SELECT id FROM participant WHERE team_id = :teamId)")
    Optional<List<AggregatedIssue>> findByParticipantTeamId(Long teamId);
}
