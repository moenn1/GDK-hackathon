package com.example.publisher.model;

import io.micronaut.core.annotation.Introspected;
import io.micronaut.data.annotation.GeneratedValue;
import io.micronaut.data.annotation.Id;
import io.micronaut.data.annotation.MappedEntity;
import io.micronaut.data.annotation.Relation;
import io.micronaut.serde.annotation.Serdeable;

import java.util.List;

@MappedEntity
@Introspected
@Serdeable
public class Team {

    @Id
    @GeneratedValue
    private Long id;

    private String name;

    @Relation(value = Relation.Kind.ONE_TO_MANY, mappedBy = "team", cascade = Relation.Cascade.ALL)
    private List<Participant> participants;

    private int bugCount;

    private int featureCount;

    private int documentationCount;

    public Team() {
    }

    public Team(Long id, String name, List<Participant> participants, int bugCount, int featureCount, int documentationCount) {
        this.id = id;
        this.name = name;
        this.participants = participants;
        this.bugCount = bugCount;
        this.featureCount = featureCount;
        this.documentationCount = documentationCount;
    }

    public List<Participant> getParticipants() {
        return participants;
    }

    public void setParticipants(List<Participant> participants) {
        this.participants = participants;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getBugCount() {
        return bugCount;
    }

    public void setBugCount(int bugCount) {
        this.bugCount = bugCount;
    }

    public int getFeatureCount() {
        return featureCount;
    }

    public void setFeatureCount(int featureCount) {
        this.featureCount = featureCount;
    }

    public int getDocumentationCount() {
        return documentationCount;
    }

    public void setDocumentationCount(int documentationCount) {
        this.documentationCount = documentationCount;
    }
}
