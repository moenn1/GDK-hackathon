package com.example.publisher.model;

import com.example.publisher.util.IssueType;
import io.micronaut.data.annotation.GeneratedValue;
import io.micronaut.data.annotation.Id;
import io.micronaut.data.annotation.MappedEntity;
import io.micronaut.data.annotation.Relation;
import io.micronaut.data.annotation.sql.JoinColumn;
import io.micronaut.serde.annotation.Serdeable;


@Serdeable
@MappedEntity
public class AggregatedIssue {

    @Id
    @GeneratedValue
    private Long id;

    private String key;
    private IssueType type;
    @Relation(Relation.Kind.MANY_TO_ONE)
    @JoinColumn(name = "participant_id")
    private Participant participant;

    public AggregatedIssue() {
    }

    public AggregatedIssue(Long id, String key, IssueType type, Participant participant) {
        this.id = id;
        this.key = key;
        this.type = type;
        this.participant = participant;
    }

    public AggregatedIssue(String key, IssueType type, Participant participant) {
        this.key = key;
        this.type = type;
        this.participant = participant;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public IssueType getType() {
        return type;
    }

    public void setType(IssueType type) {
        this.type = type;
    }

    public Participant getParticipant() {
        return participant;
    }

    public void setParticipant(Participant participant) {
        this.participant = participant;
    }
}
