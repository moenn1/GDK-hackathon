package com.example.publisher.http;

import com.example.publisher.model.JiraIssuesResponse;
import io.micronaut.core.async.annotation.SingleResult;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.Header;
import io.micronaut.http.annotation.PathVariable;
import io.micronaut.http.annotation.QueryValue;
import io.micronaut.http.client.annotation.Client;
import reactor.core.publisher.Mono;

@Client("${jira.url}")
public interface JiraClient {
//        project=GCN and "Epic Link"=%s GCN-4415
        @Get("/search?jql=project=GCN+and+\"Epic Link\"=GCN-4415")
        @Header(name = "cookie", value = "${jira.auth}")
        @SingleResult
        Mono<JiraIssuesResponse> getBugTickets(@QueryValue String ticket);
        @Get("/search?jql=project=GCN and \"Epic Link\"=GCN-4416")
        @Header(name = "cookie", value = "${jira.auth}")
        @SingleResult
        Mono<JiraIssuesResponse> getDocumentationTickets(@QueryValue String ticket);

        @Get("/search?jql=project=GCN and \"Epic Link\"=GCN-4417")
        @Header(name = "cookie", value = "${jira.auth}")
        @SingleResult
        Mono<JiraIssuesResponse> getFeatureTickets(@QueryValue String ticket);
}
