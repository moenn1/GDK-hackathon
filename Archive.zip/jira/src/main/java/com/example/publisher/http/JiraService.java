package com.example.publisher.http;

import com.example.publisher.kafka.IssueClient;
import com.example.publisher.mapper.IssueMapper;
import com.example.publisher.model.AggregatedIssue;
import com.example.publisher.model.JiraIssuesResponse;
import com.example.publisher.util.IssueType;
import jakarta.inject.Singleton;
import reactor.core.publisher.Mono;

import java.util.List;

@Singleton
public class JiraService {

        private final JiraClient jiraClient;
        private final IssueClient issueClient;
        private final IssueMapper issueMapper;

        public JiraService(JiraClient jiraClient, IssueClient issueClient, IssueMapper issueMapper) {
            this.jiraClient = jiraClient;
            this.issueClient = issueClient;
            this.issueMapper = issueMapper;
        }

    public void checkForTickets(){
        List<AggregatedIssue> aggregatedIssues = issueMapper.fromIssues(jiraClient.getBugTickets("l").block(), IssueType.BUG_TICKET);
        aggregatedIssues.addAll(issueMapper.fromIssues(jiraClient.getDocumentationTickets("l").block(), IssueType.DOCUMENTATION_TICKET));
        aggregatedIssues.addAll(issueMapper.fromIssues(jiraClient.getFeatureTickets("l").block(), IssueType.FEATURE_TICKET));
        for (AggregatedIssue issue : aggregatedIssues) {
            issueClient.sendIssue(issue);
        }
    }
}
