package com.example.publisher.controller;

import com.example.publisher.http.JiraClient;
import com.example.publisher.model.JiraIssuesResponse;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import jakarta.inject.Inject;
import reactor.core.publisher.Mono;

@Controller("/api/jira")
public class TestJiraController {
    @Inject
    private JiraClient jiraClient;

    @Get("/issues")
    public Mono<JiraIssuesResponse> getBugTickets() {
        return jiraClient.getBugTickets("k").onErrorResume(e -> {
            System.err.println("Error querying Jira: " + e.getMessage());
            return Mono.empty();
        });
    }

    @Get("/issues/documentation")
    public Mono<JiraIssuesResponse> getDocumentationTickets() {
        return jiraClient.getDocumentationTickets("l").onErrorResume(e -> {
            System.err.println("Error querying Jira: " + e.getMessage());
            return Mono.empty();
        });
    }

    @Get("/issues/feature")
    public Mono<JiraIssuesResponse> getFeatureTickets() {
        return jiraClient.getFeatureTickets("l").onErrorResume(e -> {
            System.err.println("Error querying Jira: " + e.getMessage());
            return Mono.empty();
        });
    }


}
