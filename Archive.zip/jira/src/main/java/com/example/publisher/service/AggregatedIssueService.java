package com.example.publisher.service;

import com.example.publisher.model.AggregatedIssue;
import com.example.publisher.repository.AggregatedIssueRepository;
import com.example.publisher.util.IssueType;
import jakarta.inject.Singleton;

import java.util.List;
import java.util.Optional;

@Singleton
public class AggregatedIssueService {
    private final AggregatedIssueRepository aggregatedIssueRepository;

    public AggregatedIssueService(AggregatedIssueRepository aggregatedIssueRepository) {
        this.aggregatedIssueRepository = aggregatedIssueRepository;
    }

    public void save(AggregatedIssue aggregatedIssue) {
        aggregatedIssueRepository.save(aggregatedIssue);
    }

    public void saveAll(List<AggregatedIssue> aggregatedIssues) {
        for (AggregatedIssue aggregatedIssue : aggregatedIssues) {
            if (findByKey(aggregatedIssue.getKey()) == null) {
                save(aggregatedIssue);
            }
        }
    }

    public void delete(AggregatedIssue aggregatedIssue) {
        aggregatedIssueRepository.delete(aggregatedIssue);
    }

    public void update(AggregatedIssue aggregatedIssue) {
        aggregatedIssueRepository.update(aggregatedIssue);
    }

    public AggregatedIssue findById(Long id) {
        return aggregatedIssueRepository.findById(id).orElse(null);
    }

    public Iterable<AggregatedIssue> findAll() {
        return aggregatedIssueRepository.findAll();
    }

    public Optional<List<AggregatedIssue>> findByParticipantId(Long participantId) {
        return aggregatedIssueRepository.findByParticipantId(participantId);
    }

    public Optional<List<AggregatedIssue>> findByIssueType(String type) {
        return aggregatedIssueRepository.findByIssueType(IssueType.valueOf(type));
    }

    public Optional<List<AggregatedIssue>> findByParticipantTeamId(Long teamId) {
        return aggregatedIssueRepository.findByParticipantTeamId(teamId);
    }

    public AggregatedIssue findByKey(String key) {
        return aggregatedIssueRepository.findByKey(key);
    }

    public void deleteByKey(String key) {
        AggregatedIssue aggregatedIssue = findByKey(key);
        if (aggregatedIssue != null) {
            delete(aggregatedIssue);
        }
    }
}
