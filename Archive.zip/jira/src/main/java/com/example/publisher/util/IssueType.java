package com.example.publisher.util;

public enum IssueType {
    FEATURE_TICKET, BUG_TICKET, DOCUMENTATION_TICKET;
}
