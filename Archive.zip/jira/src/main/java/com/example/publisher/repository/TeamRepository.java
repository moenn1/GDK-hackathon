package com.example.publisher.repository;

import com.example.publisher.model.Team;
import io.micronaut.data.jdbc.annotation.JdbcRepository;
import io.micronaut.data.model.query.builder.sql.Dialect;
import io.micronaut.data.repository.CrudRepository;
import jakarta.inject.Singleton;

@JdbcRepository(dialect = Dialect.MYSQL)
public interface TeamRepository extends CrudRepository<Team, Long> {
    Team findByName(String name);
}
