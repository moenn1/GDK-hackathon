package com.example.publisher.kafka;

import com.example.publisher.model.AggregatedIssue;
import com.example.publisher.repository.AggregatedIssueRepository;
import com.example.publisher.service.AggregatedIssueService;
import io.micronaut.configuration.kafka.annotation.KafkaListener;
import io.micronaut.configuration.kafka.annotation.Topic;

@KafkaListener(groupId = "jiraGroup", pollTimeout = "500ms")
public class IssueListener {

    private final AggregatedIssueService aggregatedIssueService;

    public IssueListener(AggregatedIssueService aggregatedIssueService) {
        this.aggregatedIssueService = aggregatedIssueService;
    }

    @Topic("issues")
    void updateTickets(AggregatedIssue aggregatedIssue){
        aggregatedIssueService.save(aggregatedIssue);
    }
}
